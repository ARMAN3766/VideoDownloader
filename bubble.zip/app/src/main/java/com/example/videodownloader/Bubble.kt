package com.example.videodownloader

import android.app.Activity
import android.app.Notification
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.content.ContextCompat
import kotlin.math.abs

// Floating download button over other apps.
// Copy a video link in any app, then tap the round button: the link is read and the download starts.
object Bubble {
    val supported: Boolean = true

    fun isOn(c: Context): Boolean =
        c.getSharedPreferences("vd", Context.MODE_PRIVATE).getBoolean("bubble", false)

    // Returns true when the button is on. Opens the Android permission screen the first time.
    fun setOn(c: Context, on: Boolean): Boolean {
        val p = c.getSharedPreferences("vd", Context.MODE_PRIVATE)
        if (on) {
            if (!Settings.canDrawOverlays(c)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
                return false
            }
            p.edit().putBoolean("bubble", true).apply()
            ContextCompat.startForegroundService(c, Intent(c, BubbleService::class.java))
            return true
        }
        p.edit().putBoolean("bubble", false).apply()
        c.stopService(Intent(c, BubbleService::class.java))
        return true
    }

    fun restore(c: Context) {
        try {
            if (isOn(c) && Settings.canDrawOverlays(c)) {
                ContextCompat.startForegroundService(c, Intent(c, BubbleService::class.java))
            }
        } catch (e: Throwable) {
            logCrash(e)
        }
    }
}

class BubbleService : Service() {
    private var wm: WindowManager? = null
    private var view: ImageView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DlService.createChannel(this)
        try {
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, DlService.CH)
            else Notification.Builder(this)
            b.setSmallIcon(android.R.drawable.stat_sys_download)
            b.setContentTitle(t("bubble_notif"))
            b.setOngoing(true)
            startForeground(79, b.build())
        } catch (e: Throwable) {
            logCrash(e)
        }
        if (view == null) addBubble()
        return START_STICKY
    }

    private fun addBubble() {
        try {
            val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = w
            val dm = resources.displayMetrics
            val size = (52 * dm.density).toInt()
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = dm.widthPixels - size
            lp.y = dm.heightPixels / 3
            val iv = ImageView(this)
            iv.setImageResource(R.drawable.ic_logo)
            iv.alpha = 0.9f
            iv.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0
                var sy = 0
                var tx = 0f
                var ty = 0f
                var moved = false

                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            sx = lp.x
                            sy = lp.y
                            tx = e.rawX
                            ty = e.rawY
                            moved = false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - tx).toInt()
                            val dy = (e.rawY - ty).toInt()
                            if (abs(dx) > 10 || abs(dy) > 10) moved = true
                            lp.x = sx + dx
                            lp.y = sy + dy
                            w.updateViewLayout(iv, lp)
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) {
                                val i = Intent(this@BubbleService, ClipActivity::class.java)
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(i)
                            } else {
                                lp.x = if (e.rawX < dm.widthPixels / 2f) 0 else dm.widthPixels - size
                                w.updateViewLayout(iv, lp)
                            }
                        }
                    }
                    return true
                }
            })
            w.addView(iv, lp)
            view = iv
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    override fun onDestroy() {
        try {
            val v = view
            if (v != null) wm?.removeView(v)
        } catch (e: Throwable) {
        }
        view = null
        super.onDestroy()
    }
}

// Invisible screen that is allowed to read the clipboard, then starts the download
class ClipActivity : Activity() {
    private var handled = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || handled) return
        handled = true
        val app = applicationContext
        try {
            Dm.init(app)
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val urls = parseUrls(txt)
            if (urls.isEmpty()) {
                toast(app, t("bubble_nolink"))
            } else {
                val fresh = urls.filter { Dm.findDuplicates(listOf(it)).isEmpty() }
                if (fresh.isEmpty()) {
                    toast(app, t("br_dup"))
                } else {
                    Dm.enqueue(app, fresh, defaultQuality(), "", null, false, 0)
                    toast(app, t("br_added"))
                }
            }
        } catch (e: Throwable) {
            logCrash(e)
        }
        finish()
    }
}

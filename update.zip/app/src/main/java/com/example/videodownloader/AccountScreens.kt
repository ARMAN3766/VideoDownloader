package com.example.videodownloader

import android.content.SharedPreferences
import androidx.compose.runtime.Composable

// Shown in Settings only when Cloud.enabled is true (account module)
@Composable
fun AccountSection(prefs: SharedPreferences) {
}

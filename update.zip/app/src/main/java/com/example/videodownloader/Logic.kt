package com.example.videodownloader

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.File
import java.util.Date
import java.util.Locale

var appCtx: Context? = null

val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main + CoroutineExceptionHandler { _, e -> logCrash(e) })

// UI state that is shared between screens
object Dl {
    var url by mutableStateOf("")
    var tab by mutableStateOf(0)
    var histTab by mutableStateOf(0)
    var lang by mutableStateOf("bn")
    var fetching by mutableStateOf(false)
    var fetchedUrl by mutableStateOf("")
    var fetchFailed by mutableStateOf(false)
    var fetchErr by mutableStateOf("")
    var title by mutableStateOf("")
    var thumb by mutableStateOf<String?>(null)
    var heights by mutableStateOf(listOf<Int>())
    var sel by mutableStateOf(720)
    var audio by mutableStateOf(false)
    var engineMsg by mutableStateOf("")
    var ageLimit by mutableStateOf(0)
    var cat by mutableStateOf(0)
    var catTouched by mutableStateOf(false)
    var theme by mutableStateOf(0)       // 0 dark, 1 light, 2 follow system
    var adultOk by mutableStateOf(false) // 18+ tab confirmed in this session
}

// Auto classification. Only confident signals are used:
// 1) the site itself says the video is 18+ (age_limit >= 18)
// 2) the link belongs to a dedicated adult website
// A title alone is never enough. The user can always move a video manually.
private val ADULT_HOSTS = listOf(
    "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang", "eporner",
    "tube8", "beeg", "tnaflix", "porntrex", "hqporner", "txxx", "hclips", "thisvid",
    "motherless", "porn", "xxx"
)

fun classify(url: String, ageLimit: Int): Int {
    if (ageLimit >= 18) return 1
    val host = (Uri.parse(url).host ?: "").lowercase()
    return if (ADULT_HOSTS.any { host.contains(it) }) 1 else 0
}

// ---------- crash / error log ----------

fun logCrash(e: Throwable) {
    try {
        val c = appCtx ?: return
        val f = File(c.filesDir, "crash.txt")
        val old = if (f.exists()) f.readText().takeLast(6000) else ""
        f.writeText(Date().toString() + "\n" + Log.getStackTraceString(e) + "\n----\n" + old)
    } catch (t: Throwable) {
    }
}

fun readCrash(ctx: Context): String {
    return try {
        val f = File(ctx.filesDir, "crash.txt")
        if (f.exists()) f.readText().take(4000) else ""
    } catch (t: Throwable) {
        ""
    }
}

fun clearCrash(ctx: Context) {
    try {
        File(ctx.filesDir, "crash.txt").delete()
    } catch (t: Throwable) {
    }
}

fun installCrashLogger(ctx: Context) {
    appCtx = ctx.applicationContext
    val old = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { th, e ->
        logCrash(e)
        old?.uncaughtException(th, e)
    }
}

fun toast(ctx: Context, s: String) {
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
}

fun applySecure(a: Activity, on: Boolean) {
    if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    else a.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
}

// ---------- text helpers ----------

fun parseUrls(text: String): List<String> =
    Regex("https?://\\S+").findAll(text).map { it.value.trimEnd(',', ';', ')', '"') }.toList()

fun fmtSize(b: Long): String {
    if (b <= 0L) return "-"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        b >= gb -> String.format(Locale.US, "%.2f GB", b / gb)
        b >= mb -> String.format(Locale.US, "%.1f MB", b / mb)
        else -> String.format(Locale.US, "%.0f KB", b / kb)
    }
}

fun fmtSpeed(b: Long): String = if (b <= 0L) "" else fmtSize(b) + "/s"

fun fmtEta(s: Long): String {
    if (s < 0L) return ""
    val m = s / 60
    val h = m / 60
    return if (h > 0) "${h}h ${m % 60}m" else if (m > 0) "${m}m ${s % 60}s" else "${s}s"
}

private val SIZE_RE = Regex("""of\s+~?\s*([\d.]+)\s*([KMGT]?)i?B""")
private val SPEED_RE = Regex("""at\s+([\d.]+)\s*([KMGT]?)i?B/s""")

private fun unitMul(u: String): Double = when (u) {
    "K" -> 1024.0
    "M" -> 1048576.0
    "G" -> 1073741824.0
    "T" -> 1099511627776.0
    else -> 1.0
}

fun parseTotal(line: String): Long? {
    val m = SIZE_RE.find(line) ?: return null
    val v = m.groupValues[1].toDoubleOrNull() ?: return null
    return (v * unitMul(m.groupValues[2])).toLong()
}

fun parseSpeed(line: String): Long? {
    val m = SPEED_RE.find(line) ?: return null
    val v = m.groupValues[1].toDoubleOrNull() ?: return null
    return (v * unitMul(m.groupValues[2])).toLong()
}

fun qLabel(h: Int): String = when {
    h < 0 -> t("q_audio")
    h == 0 -> t("q_best")
    h >= 2160 -> "${h}p - 4K"
    h >= 1440 -> "${h}p - 2K"
    h >= 1080 -> "${h}p - Full HD"
    h >= 720 -> "${h}p - HD"
    else -> "${h}p"
}

private val PERMANENT = listOf(
    "unsupported url", "private video", "sign in", "log in", "login", "no video formats",
    "drm", "video unavailable", "confirm your age", "http error 404", "is not a valid url",
    "no space left", "enospc", "permission"
)

fun isPermanent(raw: String): Boolean {
    val m = raw.lowercase()
    return PERMANENT.any { m.contains(it) }
}

fun friendlyError(raw: String): String {
    val m = raw.lowercase()
    return when {
        m.contains("no space left") || m.contains("enospc") -> t("err_storage")
        m.contains("unsupported url") -> t("err_unsupported")
        m.contains("private video") || m.contains("sign in") || m.contains("log in") ||
            m.contains("login") || m.contains("confirm your age") -> t("err_private")
        m.contains("drm") -> t("err_drm")
        m.contains("no video formats") -> t("err_noformat")
        m.contains("permission") -> t("err_perm")
        else -> {
            val first = raw.lineSequence().firstOrNull { it.contains("ERROR") }
            (first ?: raw).take(160)
        }
    }
}

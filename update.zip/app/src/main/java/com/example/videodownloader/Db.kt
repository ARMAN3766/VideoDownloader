package com.example.videodownloader

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Job

const val S_WAIT = 0
const val S_RUN = 1
const val S_PAUSED = 2
const val S_DONE = 3
const val S_FAILED = 4
const val S_CANCELLED = 5

// One download task. height: >0 = max height, 0 = best, -1 = audio only
class DItem(
    val id: String,
    val url: String,
    val height: Int,
    val priv: Boolean,
    var createdAt: Long
) {
    var title by mutableStateOf("")
    var thumb by mutableStateOf<String?>(null)
    var state by mutableStateOf(S_WAIT)
    var progress by mutableStateOf(0f)
    var sizeBytes by mutableStateOf(0L)
    var speed by mutableStateOf(0L)
    var eta by mutableStateOf(-1L)
    var msg by mutableStateOf("")
    var retries by mutableStateOf(0)
    var path by mutableStateOf("")
    var uri by mutableStateOf("")
    var finishedAt by mutableStateOf(0L)
    var autoPaused by mutableStateOf(false)

    // runtime only (not saved)
    var retryAt = 0L
    var cancelFlag = false
    var pauseFlag = false
    var job: Job? = null
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "vd.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE downloads (" +
                "id TEXT PRIMARY KEY, url TEXT, height INTEGER, priv INTEGER, created INTEGER, " +
                "title TEXT, thumb TEXT, state INTEGER, progress REAL, size INTEGER, msg TEXT, " +
                "retries INTEGER, path TEXT, uri TEXT, finished INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }

    fun upsert(d: DItem, savedState: Int) {
        val v = ContentValues()
        v.put("id", d.id)
        v.put("url", d.url)
        v.put("height", d.height)
        v.put("priv", if (d.priv) 1 else 0)
        v.put("created", d.createdAt)
        v.put("title", d.title)
        v.put("thumb", d.thumb)
        v.put("state", savedState)
        v.put("progress", d.progress.toDouble())
        v.put("size", d.sizeBytes)
        v.put("msg", d.msg)
        v.put("retries", d.retries)
        v.put("path", d.path)
        v.put("uri", d.uri)
        v.put("finished", d.finishedAt)
        writableDatabase.insertWithOnConflict("downloads", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun delete(id: String) {
        writableDatabase.delete("downloads", "id=?", arrayOf(id))
    }

    fun all(): List<DItem> {
        val out = ArrayList<DItem>()
        val c = readableDatabase.query("downloads", null, null, null, null, null, "created ASC")
        c.use {
            while (it.moveToNext()) {
                val d = DItem(
                    it.getString(it.getColumnIndexOrThrow("id")),
                    it.getString(it.getColumnIndexOrThrow("url")),
                    it.getInt(it.getColumnIndexOrThrow("height")),
                    it.getInt(it.getColumnIndexOrThrow("priv")) == 1,
                    it.getLong(it.getColumnIndexOrThrow("created"))
                )
                d.title = it.getString(it.getColumnIndexOrThrow("title")) ?: ""
                d.thumb = it.getString(it.getColumnIndexOrThrow("thumb"))
                d.state = it.getInt(it.getColumnIndexOrThrow("state"))
                d.progress = it.getFloat(it.getColumnIndexOrThrow("progress"))
                d.sizeBytes = it.getLong(it.getColumnIndexOrThrow("size"))
                d.msg = it.getString(it.getColumnIndexOrThrow("msg")) ?: ""
                d.retries = it.getInt(it.getColumnIndexOrThrow("retries"))
                d.path = it.getString(it.getColumnIndexOrThrow("path")) ?: ""
                d.uri = it.getString(it.getColumnIndexOrThrow("uri")) ?: ""
                d.finishedAt = it.getLong(it.getColumnIndexOrThrow("finished"))
                out.add(d)
            }
        }
        return out
    }
}

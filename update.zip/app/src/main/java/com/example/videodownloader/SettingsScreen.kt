package com.example.videodownloader

import android.content.SharedPreferences
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

// One line of the settings list: title and the current value below it
@Composable
fun SettingRow(title: String, sub: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub.isNotEmpty()) {
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// Tap an option to choose it and close the list
@Composable
fun PickDialog(title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column {
                options.forEachIndexed { i, label ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onPick(i)
                                onClose()
                            }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = i == selected, onClick = {
                            onPick(i)
                            onClose()
                        })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text(t("btn_cancel")) } }
    )
}

@Composable
fun SettingsTab(prefs: SharedPreferences) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val clip = LocalClipboardManager.current
    var dlg by remember { mutableStateOf("") }
    var secure by remember { mutableStateOf(prefs.getBoolean("secure", true)) }
    var notif by remember { mutableStateOf(prefs.getBoolean("notif", true)) }
    var wifiOnly by remember { mutableStateOf(prefs.getBoolean("wifi_only", false)) }
    var autoRetry by remember { mutableStateOf(prefs.getBoolean("auto_retry", true)) }
    var parallel by remember { mutableStateOf(prefs.getInt("parallel", 2)) }
    var vq by remember { mutableStateOf(prefs.getInt("vq", 720)) }
    var aq by remember { mutableStateOf(prefs.getString("aq", "0") ?: "0") }
    var folder by remember { mutableStateOf(prefs.getString("folder", "VideoDownloader") ?: "VideoDownloader") }
    var log by remember { mutableStateOf(readCrash(app)) }
    var storageTick by remember { mutableStateOf(0) }

    val exportL = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) toast(app, if (Dm.exportJson(app, uri)) t("export_ok") else t("op_fail"))
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val n = Dm.importJson(app, uri)
            toast(app, if (n >= 0) t("import_ok").format(n) else t("op_fail"))
        }
    }

    val version = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: ""
    } catch (e: Throwable) {
        ""
    }

    val themeKeys = listOf("theme_dark", "theme_light", "theme_system")
    val langPrefs = listOf("sys", "bn", "en")
    val langLabels = listOf(t("lang_system"), "বাংলা", "English")
    val vqValues = listOf(0, 1080, 720, 480, 360)
    val vqLabels = listOf(t("best"), "1080p", "720p", "480p", "360p")
    val aqValues = listOf("0", "192K", "128K", "64K")
    val aqLabels = listOf(t("best"), t("aq_high"), t("aq_mid"), t("aq_low"))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 8.dp)
    ) {
        Text(
            t("set_title"),
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 8.dp)
        )

        // Cloud account (visible only when the account module and keys are present)
        if (Cloud.enabled) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) { AccountSection(prefs) }
        }

        SettingRow(t("theme_title"), t(themeKeys[Dl.theme.coerceIn(0, 2)])) { dlg = "theme" }
        SettingRow(t("lang_title"), langLabels[langPrefs.indexOf(Dl.langPref).coerceAtLeast(0)]) { dlg = "lang" }
        SettingRow(t("dq_title"), vqLabels[vqValues.indexOf(vq).coerceAtLeast(0)]) { dlg = "vq" }
        SettingRow(t("aq_title"), aqLabels[aqValues.indexOf(aq).coerceAtLeast(0)]) { dlg = "aq" }
        SettingRow(t("folder_title"), "Movies/" + folder + "  -  Music/" + folder) { dlg = "folder" }
        SwitchRow(t("wifi_title"), wifiOnly) { v ->
            wifiOnly = v
            prefs.edit().putBoolean("wifi_only", v).apply()
            Dm.enforcePolicy(app)
            Dm.resumeAuto(app)
        }
        SettingRow(t("parallel_title"), parallel.toString()) { dlg = "parallel" }
        SwitchRow(t("retry_title"), autoRetry) { v ->
            autoRetry = v
            prefs.edit().putBoolean("auto_retry", v).apply()
        }
        SwitchRow(t("notif_title"), notif) { v ->
            notif = v
            prefs.edit().putBoolean("notif", v).apply()
        }
        SwitchRow(t("secure_title"), secure) { v ->
            secure = v
            prefs.edit().putBoolean("secure", v).apply()
            (ctx as? android.app.Activity)?.let { applySecure(it, v) }
        }
        SettingRow(t("backup_title"), "") { dlg = "backup" }
        SettingRow(
            t("engine_title"),
            if (Dl.engineMsg.isNotEmpty()) Dl.engineMsg else t("btn_update_engine")
        ) {
            if (Dl.engineMsg.isEmpty() && Dm.items.none { it.state == S_RUN }) Engine.start(app, prefs, true)
        }
        SettingRow(t("crash_title"), if (log.isEmpty()) t("crash_none") else "!") { dlg = "log" }
        SettingRow(t("clear_cache"), "") {
            val freed = Dm.clearCache(app)
            toast(app, t("cache_cleared").format(fmtSize(freed)))
        }
        SettingRow(t("manage_storage"), "") {
            storageTick++
            dlg = "storage"
        }
        SettingRow(t("about_title"), "") { dlg = "about" }
        Spacer(Modifier.height(24.dp))
    }

    when (dlg) {
        "theme" -> PickDialog(
            t("theme_title"), themeKeys.map { t(it) }, Dl.theme.coerceIn(0, 2),
            onPick = { i ->
                Dl.theme = i
                prefs.edit().putInt("theme", i).apply()
            },
            onClose = { dlg = "" }
        )
        "lang" -> PickDialog(
            t("lang_title"), langLabels, langPrefs.indexOf(Dl.langPref).coerceAtLeast(0),
            onPick = { i ->
                applyLang(langPrefs[i])
                prefs.edit().putString("lang", langPrefs[i]).apply()
            },
            onClose = { dlg = "" }
        )
        "vq" -> PickDialog(
            t("dq_title"), vqLabels, vqValues.indexOf(vq).coerceAtLeast(0),
            onPick = { i ->
                vq = vqValues[i]
                prefs.edit().putInt("vq", vq).apply()
                Dl.sel = vq
            },
            onClose = { dlg = "" }
        )
        "aq" -> PickDialog(
            t("aq_title"), aqLabels, aqValues.indexOf(aq).coerceAtLeast(0),
            onPick = { i ->
                aq = aqValues[i]
                prefs.edit().putString("aq", aq).apply()
            },
            onClose = { dlg = "" }
        )
        "parallel" -> PickDialog(
            t("parallel_title"), listOf("1", "2", "3", "4", "5"), (parallel - 1).coerceIn(0, 4),
            onPick = { i ->
                parallel = i + 1
                prefs.edit().putInt("parallel", parallel).apply()
                Dm.pump(app)
            },
            onClose = { dlg = "" }
        )
        "folder" -> {
            var f by remember { mutableStateOf(folder) }
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text(t("folder_title")) },
                text = {
                    OutlinedTextField(
                        value = f,
                        onValueChange = { v ->
                            f = v.filter { c -> c.isLetterOrDigit() || c == '_' || c == '-' || c == ' ' }
                        },
                        label = { Text(t("folder_name")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        folder = f.trim().ifBlank { "VideoDownloader" }
                        prefs.edit().putString("folder", folder).apply()
                        dlg = ""
                    }) { Text(t("btn_save")) }
                },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("btn_cancel")) } }
            )
        }
        "backup" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t("backup_title")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            dlg = ""
                            exportL.launch("video_downloader_history.json")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(t("btn_export")) }
                    OutlinedButton(
                        onClick = {
                            dlg = ""
                            importL.launch(arrayOf("application/json", "text/plain", "*/*"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(t("btn_import")) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("close")) } }
        )
        "log" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t("crash_title")) },
            text = {
                if (log.isEmpty()) {
                    Text(t("crash_none"))
                } else {
                    Text(log.take(1200), style = MaterialTheme.typography.bodySmall, maxLines = 16)
                }
            },
            confirmButton = {
                if (log.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            clip.setText(AnnotatedString(log))
                            toast(app, t("copied"))
                        }) { Text(t("btn_copy")) }
                        TextButton(onClick = {
                            clearCrash(app)
                            log = ""
                            dlg = ""
                        }) { Text(t("btn_clear_log")) }
                    }
                }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("close")) } }
        )
        "storage" -> {
            val info = remember(storageTick) { Dm.storageInfo(app) }
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text(t("manage_storage")) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(t("st_files") + ": " + info.files + "  -  " + fmtSize(info.filesBytes))
                        Text(t("st_partial") + ": " + fmtSize(info.partialBytes))
                        Text(t("st_cache") + ": " + fmtSize(info.cacheBytes))
                        Text(t("st_free") + ": " + fmtSize(info.freeBytes))
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = info.partialBytes > 0L,
                        onClick = {
                            val freed = Dm.deletePartial(app)
                            toast(app, t("partial_deleted").format(fmtSize(freed)))
                            storageTick++
                        }
                    ) { Text(t("btn_delete_partial")) }
                },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("close")) } }
            )
        }
        "about" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t("app_title")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t("version_label") + ": " + version)
                    Text(t("about_body"))
                    Text(t("supported_note"), style = MaterialTheme.typography.bodySmall)
                    Text(
                        t("privacy_note"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("close")) } }
        )
        else -> {
        }
    }
}

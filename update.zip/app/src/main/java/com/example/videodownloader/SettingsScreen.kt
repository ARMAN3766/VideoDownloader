package com.example.videodownloader

import android.content.Context
import android.content.SharedPreferences
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

@Composable
fun SettingsTab(prefs: SharedPreferences) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val clip = LocalClipboardManager.current
    var secure by remember { mutableStateOf(prefs.getBoolean("secure", true)) }
    var privDef by remember { mutableStateOf(prefs.getBoolean("priv_default", false)) }
    var parallel by remember { mutableStateOf(prefs.getInt("parallel", 2)) }
    var folder by remember { mutableStateOf(prefs.getString("folder", "VideoDownloader") ?: "VideoDownloader") }
    var log by remember { mutableStateOf(readCrash(app)) }

    val exportL = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) toast(app, if (Dm.exportJson(app, uri)) t("export_ok") else t("op_fail"))
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val n = Dm.importJson(app, uri)
            toast(app, if (n >= 0) t("import_ok").format(n) else t("op_fail"))
        }
    }

    val version = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: ""
    } catch (e: Throwable) {
        ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(t("set_title"), style = MaterialTheme.typography.headlineSmall)

        AppCard {
            Text(t("lang_title"), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = Dl.lang == "bn",
                    onClick = {
                        Dl.lang = "bn"
                        prefs.edit().putString("lang", "bn").apply()
                    },
                    label = { Text("বাংলা") }
                )
                FilterChip(
                    selected = Dl.lang == "en",
                    onClick = {
                        Dl.lang = "en"
                        prefs.edit().putString("lang", "en").apply()
                    },
                    label = { Text("English") }
                )
            }
        }

        AppCard {
            Text(t("parallel_title"), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3, 4).forEach { n ->
                    FilterChip(
                        selected = parallel == n,
                        onClick = {
                            parallel = n
                            prefs.edit().putInt("parallel", n).apply()
                            Dm.pump(app)
                        },
                        label = { Text(n.toString()) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = folder,
                onValueChange = { v ->
                    val f = v.filter { c -> c.isLetterOrDigit() || c == '_' || c == '-' || c == ' ' }
                    folder = f
                    prefs.edit().putString("folder", f).apply()
                },
                label = { Text(t("folder_name")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t("priv_default"), modifier = Modifier.weight(1f))
                Switch(checked = privDef, onCheckedChange = { v ->
                    privDef = v
                    prefs.edit().putBoolean("priv_default", v).apply()
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t("secure_title"), modifier = Modifier.weight(1f))
                Switch(checked = secure, onCheckedChange = { v ->
                    secure = v
                    prefs.edit().putBoolean("secure", v).apply()
                    (ctx as? android.app.Activity)?.let { applySecure(it, v) }
                })
            }
        }

        AppCard {
            Text(t("backup_title"), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportL.launch("video_downloader_history.json") }) {
                    Text(t("btn_export"))
                }
                OutlinedButton(onClick = {
                    importL.launch(arrayOf("application/json", "text/plain", "*/*"))
                }) { Text(t("btn_import")) }
            }
        }

        AppCard {
            Text(t("engine_title"), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                enabled = Dl.engineMsg.isEmpty() && Dm.items.none { it.state == S_RUN },
                onClick = { Engine.start(app, prefs, true) }
            ) { Text(t("btn_update_engine")) }
            if (Dl.engineMsg.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(Dl.engineMsg, style = MaterialTheme.typography.bodySmall)
            }
        }

        AppCard {
            Text(t("crash_title"), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            if (log.isEmpty()) {
                Text(
                    t("crash_none"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(log.take(1200), style = MaterialTheme.typography.bodySmall, maxLines = 14)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(log))
                        toast(app, t("copied"))
                    }) { Text(t("btn_copy")) }
                    OutlinedButton(onClick = {
                        clearCrash(app)
                        log = ""
                    }) { Text(t("btn_clear_log")) }
                }
            }
        }

        Text(
            t("privacy_note"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            t("version_label") + ": " + version,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

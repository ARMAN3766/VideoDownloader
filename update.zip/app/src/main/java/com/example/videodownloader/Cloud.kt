package com.example.videodownloader

import android.content.Context

// Cloud account + history sync is OFF in this build.
// It turns on only when the account module is added and the Firebase keys are provided.
object Cloud {
    val enabled: Boolean = false

    fun init(ctx: Context) {
    }

    fun syncNow(ctx: Context) {
    }

    fun onDone(ctx: Context, d: DItem) {
    }

    fun onRemove(ctx: Context, id: String) {
    }
}

package com.example.videodownloader

import android.content.Context
import android.content.SharedPreferences
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Keeps the yt-dlp engine fresh. Downloads wait for the update to finish.
object Engine {
    private var job: Deferred<Unit>? = null

    fun start(ctx: Context, prefs: SharedPreferences, force: Boolean = false) {
        if (job != null && !force) return
        job = appScope.async(Dispatchers.IO) {
            try {
                val last = prefs.getLong("ytdlp_upd", 0L)
                if (force || System.currentTimeMillis() - last > 12L * 3600L * 1000L) {
                    Dl.engineMsg = t("engine_updating")
                    YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
                    prefs.edit().putLong("ytdlp_upd", System.currentTimeMillis()).apply()
                }
            } catch (e: Throwable) {
                logCrash(e)
            }
            Dl.engineMsg = ""
        }
    }

    suspend fun await() {
        job?.await()
    }
}

private var fetchToken = 0

fun resetPreview() {
    fetchToken++
    Dl.fetching = false
    Dl.fetchedUrl = ""
    Dl.fetchFailed = false
    Dl.fetchErr = ""
    Dl.title = ""
    Dl.thumb = null
    Dl.heights = listOf()
}

// Looks up the first link: title, thumbnail and the qualities that really exist
fun fetchInfo() {
    val first = parseUrls(Dl.url).firstOrNull() ?: return
    val token = ++fetchToken
    Dl.fetching = true
    Dl.fetchFailed = false
    Dl.fetchErr = ""
    Dl.fetchedUrl = first
    Dl.title = ""
    Dl.thumb = null
    Dl.heights = listOf()
    appScope.launch {
        try {
            Engine.await()
            val r = withContext(Dispatchers.IO) {
                val req = YoutubeDLRequest(first)
                req.addOption("--no-playlist")
                YoutubeDL.getInstance().getInfo(req)
            }
            if (token == fetchToken) {
                Dl.title = r.title ?: ""
                Dl.thumb = r.thumbnail
                val hs = (r.formats ?: emptyList())
                    .filter { it.height > 0 }
                    .map { it.height }
                    .distinct()
                    .sortedDescending()
                if (hs.isEmpty()) {
                    Dl.fetchFailed = true
                    Dl.heights = listOf(1080, 720, 480, 360)
                } else {
                    Dl.heights = hs
                }
                Dl.sel = Dl.heights.firstOrNull { it <= 720 } ?: Dl.heights.last()
            }
        } catch (e: Throwable) {
            if (token == fetchToken) {
                Dl.fetchFailed = true
                Dl.fetchErr = friendlyError(e.message ?: e.toString())
                Dl.heights = listOf(1080, 720, 480, 360)
                Dl.sel = 720
            }
        }
        if (token == fetchToken) Dl.fetching = false
    }
}

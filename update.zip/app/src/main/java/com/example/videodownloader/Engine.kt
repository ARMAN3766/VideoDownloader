package com.example.videodownloader

import android.content.Context
import android.content.SharedPreferences
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

// Keeps the yt-dlp engine fresh. Downloads wait for the update to finish.
object Engine {
    private var job: Deferred<Unit>? = null

    fun start(ctx: Context, prefs: SharedPreferences, force: Boolean = false) {
        if (job != null && !force) return
        job = appScope.async(Dispatchers.IO) {
            try {
                val last = prefs.getLong("ytdlp_upd", 0L)
                if (force || System.currentTimeMillis() - last > 12L * 3600L * 1000L) {
                    Dl.engineMsg = t("engine_updating")
                    YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
                    prefs.edit().putLong("ytdlp_upd", System.currentTimeMillis()).apply()
                }
            } catch (e: Throwable) {
                logCrash(e)
            }
            Dl.engineMsg = ""
        }
    }

    suspend fun await() {
        job?.await()
    }
}

// What the site tells us about a video
class Meta(val title: String, val thumb: String?, val heights: List<Int>)

private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k)

// Blocking. Call from a background thread.
fun readMeta(url: String, pid: String?): Meta {
    val req = YoutubeDLRequest(url)
    req.addOption("--dump-json")
    req.addOption("--no-playlist")
    val resp = YoutubeDL.getInstance().execute(req, pid) { _, _, _ -> }
    val line = resp.out.lineSequence().firstOrNull { it.trim().startsWith("{") }
        ?: throw Exception("No video information")
    val j = JSONObject(line.trim())
    val hs = ArrayList<Int>()
    val fm = j.optJSONArray("formats")
    if (fm != null) {
        for (i in 0 until fm.length()) {
            val o = fm.optJSONObject(i) ?: continue
            val h = o.optInt("height", 0)
            if (h > 0 && !hs.contains(h)) hs.add(h)
        }
    }
    hs.sortDescending()
    val th = j.str("thumbnail")
    return Meta(
        j.str("title") ?: "",
        if (th.isNullOrBlank()) null else th,
        hs
    )
}

private var fetchToken = 0

// The default quality from Settings, matched to what the video really offers
private fun pickQuality(heights: List<Int>): Int {
    val q = defaultQuality()
    return if (q == 0) 0 else (heights.firstOrNull { it <= q } ?: heights.last())
}

fun resetPreview() {
    fetchToken++
    Dl.fetching = false
    Dl.fetchedUrl = ""
    Dl.fetchFailed = false
    Dl.fetchErr = ""
    Dl.title = ""
    Dl.thumb = null
    Dl.heights = listOf()
}

// Looks up the first link: title, thumbnail and the qualities that really exist
fun fetchInfo() {
    val first = parseUrls(Dl.url).firstOrNull() ?: return
    val token = ++fetchToken
    Dl.fetching = true
    Dl.fetchFailed = false
    Dl.fetchErr = ""
    Dl.fetchedUrl = first
    Dl.title = ""
    Dl.thumb = null
    Dl.heights = listOf()
    appScope.launch {
        try {
            Engine.await()
            val m = withContext(Dispatchers.IO) { readMeta(first, null) }
            if (token == fetchToken) {
                Dl.title = m.title
                Dl.thumb = m.thumb
                if (m.heights.isEmpty()) {
                    Dl.fetchFailed = true
                    Dl.heights = listOf(1080, 720, 480, 360)
                } else {
                    Dl.heights = m.heights
                }
                Dl.sel = pickQuality(Dl.heights)
            }
        } catch (e: Throwable) {
            if (token == fetchToken) {
                Dl.fetchFailed = true
                Dl.fetchErr = friendlyError(e.message ?: e.toString())
                Dl.heights = listOf(1080, 720, 480, 360)
                Dl.sel = pickQuality(Dl.heights)
            }
        }
        if (token == fetchToken) Dl.fetching = false
    }
}

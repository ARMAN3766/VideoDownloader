package com.example.videodownloader

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun statusLine(d: DItem): String = when (d.state) {
    S_RUN -> t("st_run") +
        (if (d.speed > 0L) " - " + fmtSpeed(d.speed) else "") +
        (if (d.eta > 0L) " - " + fmtEta(d.eta) else "")
    S_WAIT -> t("st_wait") + (if (d.retries > 0) " - " + t("retry_n").format(d.retries) else "")
    S_PAUSED -> t("st_paused") + (if (d.autoPaused) " - " + t("waiting_net") else "")
    S_FAILED -> t("st_failed") + (if (d.msg.isNotEmpty()) " - " + d.msg else "")
    S_CANCELLED -> t("st_cancelled")
    else -> t("st_done")
}

fun shareItem(ctx: Context, d: DItem) {
    try {
        val uri: Uri = if (d.priv) {
            val p = Uri.parse(d.uri).path ?: throw Exception("no path")
            FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(p))
        } else {
            Uri.parse(d.uri)
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = if (d.height < 0) "audio/*" else "video/*"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, null))
    } catch (e: Throwable) {
        toast(ctx, t("file_missing"))
    }
}

@Composable
fun HistoryTab() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val active = Dm.items.filter { it.state != S_DONE }
    val done = Dm.items.filter { it.state == S_DONE }.sortedByDescending { it.finishedAt }
    var play by remember { mutableStateOf<DItem?>(null) }
    var cancelTarget by remember { mutableStateOf<DItem?>(null) }
    var deleteTarget by remember { mutableStateOf<DItem?>(null) }
    var clearMode by remember { mutableStateOf(0) } // 0 none, 1 history only, 2 history + files

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(t("tab_hist"))
        TabRow(
            selectedTabIndex = Dl.histTab,
            containerColor = MaterialTheme.colorScheme.background
        ) {
            Tab(
                selected = Dl.histTab == 0,
                onClick = { Dl.histTab = 0 },
                text = { Text(t("sec_downloads") + " (" + active.size + ")") }
            )
            Tab(
                selected = Dl.histTab == 1,
                onClick = { Dl.histTab = 1 },
                text = { Text(t("sec_completed") + " (" + done.size + ")") }
            )
        }

        if (Dl.histTab == 0) {
            if (active.isEmpty()) {
                Text(
                    t("empty_downloads"),
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(active, key = { it.id }) { d ->
                    DownloadCard(d, app, onCancel = { cancelTarget = d })
                }
            }
        } else {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    enabled = done.isNotEmpty(),
                    onClick = { clearMode = 1 }
                ) { Text(t("clear_history")) }
                OutlinedButton(
                    enabled = done.isNotEmpty(),
                    onClick = { clearMode = 2 }
                ) { Text(t("clear_files")) }
            }
            if (done.isEmpty()) {
                Text(
                    t("empty_completed"),
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(done, key = { it.id }) { d ->
                    DoneCard(
                        d,
                        onPlay = { if (d.uri.isEmpty()) toast(ctx, t("file_missing")) else play = d },
                        onShare = { if (d.uri.isEmpty()) toast(ctx, t("file_missing")) else shareItem(ctx, d) },
                        onAgain = {
                            Dm.enqueue(app, listOf(d.url), d.height, d.priv, d.title, d.thumb)
                            Dl.histTab = 0
                        },
                        onDelete = { deleteTarget = d }
                    )
                }
            }
        }
    }

    val ct = cancelTarget
    if (ct != null) {
        AlertDialog(
            onDismissRequest = { cancelTarget = null },
            title = { Text(t("cancel_q_title")) },
            text = { Text(t("cancel_q_body")) },
            confirmButton = {
                Button(onClick = {
                    Dm.cancel(app, ct)
                    cancelTarget = null
                }) { Text(t("yes")) }
            },
            dismissButton = { TextButton(onClick = { cancelTarget = null }) { Text(t("no")) } }
        )
    }

    val dt = deleteTarget
    if (dt != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(t("btn_delete")) },
            text = { Text(t("delete_q_body")) },
            confirmButton = {
                Button(onClick = {
                    Dm.remove(app, dt, true)
                    deleteTarget = null
                }) { Text(t("yes")) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text(t("no")) } }
        )
    }

    if (clearMode != 0) {
        AlertDialog(
            onDismissRequest = { clearMode = 0 },
            title = { Text(t("clear_q_title")) },
            text = { Text(if (clearMode == 2) t("clear_files_body") else t("clear_q_body")) },
            confirmButton = {
                Button(onClick = {
                    Dm.clearCompleted(app, clearMode == 2)
                    clearMode = 0
                }) { Text(t("yes")) }
            },
            dismissButton = { TextButton(onClick = { clearMode = 0 }) { Text(t("no")) } }
        )
    }

    val p = play
    if (p != null) PlayerDialog(p) { play = null }
}

// Active download: thumbnail, name, quality, size, speed, time left, status, ring progress, cancel
@Composable
fun DownloadCard(d: DItem, app: Context, onCancel: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Thumb(d.thumb, Modifier.width(96.dp).height(60.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    d.title,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    qLabel(d.height) + (if (d.sizeBytes > 0L) " - " + fmtSize(d.sizeBytes) else ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    statusLine(d),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (d.state == S_FAILED) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            RingProgress(d.progress, 64.dp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            when (d.state) {
                S_RUN, S_WAIT -> {
                    TextButton(onClick = { Dm.pause(app, d) }) { Text(t("btn_pause")) }
                    TextButton(onClick = onCancel) {
                        Text(t("btn_cancel"), color = MaterialTheme.colorScheme.error)
                    }
                }
                S_PAUSED -> {
                    TextButton(onClick = { Dm.resume(app, d) }) { Text(t("btn_resume")) }
                    TextButton(onClick = onCancel) {
                        Text(t("btn_cancel"), color = MaterialTheme.colorScheme.error)
                    }
                }
                else -> {
                    TextButton(onClick = { Dm.retry(app, d) }) { Text(t("btn_retry")) }
                    TextButton(onClick = { Dm.remove(app, d, false) }) { Text(t("btn_remove")) }
                }
            }
        }
    }
}

// Finished download: thumbnail, name, date, size, quality, play, share, download again, delete
@Composable
fun DoneCard(d: DItem, onPlay: () -> Unit, onShare: () -> Unit, onAgain: () -> Unit, onDelete: () -> Unit) {
    val fmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Thumb(d.thumb, Modifier.width(96.dp).height(60.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    d.title,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    qLabel(d.height) + " - " + fmtSize(d.sizeBytes) + " - " + fmt.format(Date(d.finishedAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (d.priv) {
                    Text(
                        t("private_tag"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
                if (d.uri.isEmpty()) {
                    Text(
                        t("imported_note"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            if (d.uri.isNotEmpty()) {
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = t("btn_play"))
                }
                IconButton(onClick = onShare) {
                    Icon(Icons.Default.Share, contentDescription = t("btn_share"))
                }
            }
            IconButton(onClick = onAgain) {
                Icon(Icons.Default.Download, contentDescription = t("btn_again"))
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = t("btn_delete"),
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
fun PlayerDialog(d: DItem, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val secure = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE).getBoolean("secure", true)
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(
            securePolicy = if (secure) SecureFlagPolicy.SecureOn else SecureFlagPolicy.Inherit
        )
    ) {
        Surface(shape = MaterialTheme.shapes.medium) {
            Column(Modifier.padding(8.dp)) {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            val mc = MediaController(c)
                            mc.setAnchorView(this)
                            setMediaController(mc)
                            setVideoURI(Uri.parse(d.uri))
                            start()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(280.dp)
                )
                TextButton(onClick = onClose) { Text(t("close")) }
            }
        }
    }
}

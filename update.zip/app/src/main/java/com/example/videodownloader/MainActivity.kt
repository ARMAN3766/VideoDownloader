package com.example.videodownloader

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("vd", Context.MODE_PRIVATE)
        Dm.init(applicationContext)
        applyLang(prefs.getString("lang", "bn") ?: "bn")
        Dl.sel = defaultQuality()
        Dl.theme = prefs.getInt("theme", 0)
        Cloud.init(applicationContext)
        applySecure(this, prefs.getBoolean("secure", true))
        Engine.start(applicationContext, prefs)
        handleShare(intent)
        addOnNewIntentListener { handleShare(it) }
        askPermissions()
        Dm.pump(applicationContext)
        Cloud.syncNow(applicationContext)
        setContent { AppTheme { MainScreen(prefs) { finish() } } }
    }

    // Links shared from other apps (Facebook, YouTube, browser ...)
    private fun handleShare(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_SEND) {
            val txt = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!txt.isNullOrBlank()) {
                Dl.url = parseUrls(txt).firstOrNull() ?: txt
                Dl.tab = 0
            }
        }
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) need.add("android.permission.POST_NOTIFICATIONS")
        if (Build.VERSION.SDK_INT < 29) need.add("android.permission.WRITE_EXTERNAL_STORAGE")
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }
}

@Composable
fun MainScreen(prefs: SharedPreferences, onExit: () -> Unit) {
    var consent by remember { mutableStateOf(prefs.getBoolean("age_ok", false)) }
    val active = Dm.items.count { it.state == S_WAIT || it.state == S_RUN || it.state == S_PAUSED }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = Dl.tab == 0,
                    onClick = { Dl.tab = 0 },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    label = { Text(t("tab_dl")) }
                )
                NavigationBarItem(
                    selected = Dl.tab == 1,
                    onClick = { Dl.tab = 1 },
                    icon = {
                        if (active > 0) {
                            BadgedBox(badge = { Badge { Text(active.toString()) } }) {
                                Icon(Icons.Default.History, contentDescription = null)
                            }
                        } else {
                            Icon(Icons.Default.History, contentDescription = null)
                        }
                    },
                    label = { Text(t("tab_hist")) }
                )
                NavigationBarItem(
                    selected = Dl.tab == 2,
                    onClick = { Dl.tab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text(t("tab_set")) }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (Dl.tab) {
                0 -> DownloadTab(prefs)
                1 -> HistoryTab()
                else -> SettingsTab(prefs)
            }
        }
    }
    if (!consent) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(t("consent_title"), fontWeight = FontWeight.Bold) },
            text = { Text(t("consent_body")) },
            confirmButton = {
                Button(onClick = {
                    prefs.edit().putBoolean("age_ok", true).apply()
                    consent = true
                }) { Text(t("consent_ok")) }
            },
            dismissButton = {
                TextButton(onClick = onExit) { Text(t("consent_exit")) }
            }
        )
    }
}

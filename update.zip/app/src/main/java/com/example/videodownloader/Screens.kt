package com.example.videodownloader

import android.content.SharedPreferences
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// Download page: paste (or share) a link, see real qualities, press Download.
// The input box is never locked, so the next link can be added at once.
@Composable
fun DownloadTab(prefs: SharedPreferences) {
    val app = LocalContext.current.applicationContext
    val clip = LocalClipboardManager.current
    var note by remember { mutableStateOf("") }
    var dup by remember { mutableStateOf<List<String>?>(null) }

    // Look up the video automatically when a new link appears
    LaunchedEffect(Dl.url) {
        val first = parseUrls(Dl.url).firstOrNull()
        if (first == null) {
            if (Dl.fetchedUrl.isNotEmpty()) resetPreview()
        } else if (first != Dl.fetchedUrl) {
            delay(700)
            fetchInfo()
        }
    }

    fun submit(skipDuplicates: Boolean) {
        val all = parseUrls(Dl.url)
        val dups = Dm.findDuplicates(all)
        val list = if (skipDuplicates) all.filter { it !in dups } else all
        if (list.isNotEmpty()) {
            val q = if (Dl.audio) -1 else Dl.sel
            val withPreview = list.first() == Dl.fetchedUrl && !Dl.fetching
            Dm.enqueue(
                app, list, q,
                if (withPreview) Dl.title else "",
                if (withPreview) Dl.thumb else null,
                if (withPreview || Dl.catTouched) Dl.cat else classify(list.first(), 0),
                Dl.catTouched,
                withPreview
            )
            note = t("added_n").format(list.size)
        }
        // the box is free again for the next link
        Dl.url = ""
        resetPreview()
        dup = null
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(t("dl_sub"))
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AppCard {
                OutlinedTextField(
                    value = Dl.url,
                    onValueChange = { Dl.url = it },
                    label = { Text(t("paste_link")) },
                    minLines = 3,
                    maxLines = 6,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    t("multi_hint"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = {
                        clip.getText()?.text?.let { Dl.url = it }
                    }) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(t("btn_paste"))
                    }
                    OutlinedButton(
                        enabled = parseUrls(Dl.url).isNotEmpty(),
                        onClick = { fetchInfo() }
                    ) { Text(t("btn_preview")) }
                    OutlinedButton(onClick = {
                        Dl.url = ""
                        resetPreview()
                        note = ""
                    }) {
                        Icon(Icons.Default.Close, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(t("btn_clear"))
                    }
                }
            }

            if (Dl.engineMsg.isNotEmpty()) {
                Text(
                    Dl.engineMsg,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (Dl.fetching) {
                AppCard {
                    Text(t("searching"))
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }

            if (!Dl.fetching && Dl.fetchedUrl.isNotEmpty()) {
                AppCard {
                    if (Dl.thumb != null) {
                        AsyncImage(
                            model = Dl.thumb,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .clip(RoundedCornerShape(18.dp))
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    if (Dl.title.isNotEmpty()) {
                        Text(Dl.title, style = MaterialTheme.typography.titleMedium, maxLines = 3)
                    }
                    if (Dl.fetchFailed) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            t("no_formats_note") + (if (Dl.fetchErr.isNotEmpty()) "\n" + Dl.fetchErr else ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                AppCard {
                    Text(t("choose_quality"), style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Dl.heights.forEach { h ->
                            FilterChip(
                                selected = Dl.sel == h,
                                onClick = { Dl.sel = h },
                                enabled = !Dl.audio,
                                label = { Text(qLabel(h)) }
                            )
                        }
                        FilterChip(
                            selected = Dl.sel == 0,
                            onClick = { Dl.sel = 0 },
                            enabled = !Dl.audio,
                            label = { Text(qLabel(0)) }
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t("audio_only"), modifier = Modifier.weight(1f))
                        Switch(checked = Dl.audio, onCheckedChange = { Dl.audio = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t("adult_switch"), modifier = Modifier.weight(1f))
                        Switch(checked = Dl.cat == 1, onCheckedChange = {
                            Dl.cat = if (it) 1 else 0
                            Dl.catTouched = true
                        })
                    }
                    if (Dl.cat == 1 && !Dl.catTouched) {
                        Text(
                            t("adult_detected"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }

            GradientButton(
                text = t("btn_download"),
                icon = Icons.Default.Download,
                onClick = {
                    val all = parseUrls(Dl.url)
                    if (all.isEmpty()) {
                        note = t("enter_link")
                    } else {
                        val d = Dm.findDuplicates(all)
                        if (d.isNotEmpty()) dup = d else submit(false)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            if (note.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(note, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.secondary)
                    TextButton(onClick = {
                        Dl.histTab = 0
                        Dl.tab = 1
                    }) { Text(t("view_downloads")) }
                }
            }

            Text(
                t("supported_note"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    val d = dup
    if (d != null) {
        AlertDialog(
            onDismissRequest = { dup = null },
            title = { Text(t("dup_title")) },
            text = { Text(t("dup_body").format(d.size)) },
            confirmButton = { Button(onClick = { submit(false) }) { Text(t("dup_add_all")) } },
            dismissButton = { TextButton(onClick = { submit(true) }) { Text(t("dup_skip")) } }
        )
    }
}

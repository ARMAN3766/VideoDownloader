package com.example.videodownloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

fun isOnline(ctx: Context): Boolean {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Throwable) {
        true
    }
}

fun isWifi(ctx: Context): Boolean {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    } catch (e: Throwable) {
        true
    }
}

// Online, and on Wi-Fi when "Wi-Fi only downloads" is switched on
fun canDownload(ctx: Context): Boolean {
    if (!isOnline(ctx)) return false
    val wifiOnly = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE).getBoolean("wifi_only", false)
    return !wifiOnly || isWifi(ctx)
}

class StorageInfo(
    val files: Int, val filesBytes: Long, val partialBytes: Long, val cacheBytes: Long, val freeBytes: Long
)

private fun dirSize(f: File): Long =
    if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

// Download manager: queue, parallel limit, retry with delay, cancel, pause, resume
object Dm {
    val items = mutableStateListOf<DItem>()
    private var db: Db? = null
    private var inited = false
    private var lastNotif = 0L
    private val RETRY_DELAYS = longArrayOf(5000L, 20000L, 60000L, 120000L)
    private val MEDIA_EXT = listOf("mp4", "mkv", "webm", "mp3", "m4a", "opus", "ogg", "flv", "mov", "avi", "ts", "3gp", "aac", "wav")
    private val IMG_EXT = listOf("jpg", "jpeg", "png", "webp")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val c = ctx.applicationContext
        appCtx = c
        applyLang(prefs(c).getString("lang", "bn") ?: "bn")
        val d = Db(c)
        db = d
        try {
            for (x in d.all()) {
                if (x.state == S_RUN) x.state = S_WAIT
                items.add(x)
            }
        } catch (e: Throwable) {
            logCrash(e)
        }
        registerNetwork(c)
    }

    fun save(d: DItem) {
        try {
            val st = if (d.state == S_PAUSED && d.autoPaused) S_WAIT else d.state
            db?.upsert(d, st)
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    fun hasPending(): Boolean =
        items.any { it.state == S_WAIT || it.state == S_RUN || (it.state == S_PAUSED && it.autoPaused) }

    fun findDuplicates(urls: List<String>): List<String> =
        urls.filter { u -> items.any { it.url == u && it.state != S_CANCELLED && it.state != S_FAILED } }

    // firstHasMeta: the first link was already previewed, so title and thumbnail are known
    fun enqueue(
        ctx: Context, urls: List<String>, height: Int, title: String, thumb: String?,
        firstHasMeta: Boolean
    ) {
        urls.forEachIndexed { i, u ->
            val d = DItem(UUID.randomUUID().toString(), u, height, System.currentTimeMillis() + i)
            d.title = if (i == 0 && title.isNotBlank()) title else u
            d.thumb = if (i == 0) thumb else null
            d.meta = i == 0 && firstHasMeta
            items.add(d)
            save(d)
        }
        pump(ctx)
    }

    // Starts waiting items in order, up to the parallel limit
    fun pump(ctx: Context) {
        val c = ctx.applicationContext
        val now = System.currentTimeMillis()
        val limit = prefs(c).getInt("parallel", 2).coerceIn(1, 5)
        var running = items.count { it.state == S_RUN }
        for (d in items.toList()) {
            if (running >= limit) break
            if (d.state == S_WAIT && d.retryAt <= now) {
                if (!canDownload(c)) {
                    d.state = S_PAUSED
                    d.autoPaused = true
                    save(d)
                    continue
                }
                startItem(c, d)
                running++
            }
        }
        DlService.sync(c, hasPending())
    }

    private fun startItem(c: Context, d: DItem) {
        d.state = S_RUN
        d.msg = ""
        d.cancelFlag = false
        d.pauseFlag = false
        d.autoFlag = false
        d.speed = 0L
        d.eta = -1L
        save(d)
        d.job = appScope.launch {
            try {
                Engine.await()
                if (d.cancelFlag || d.pauseFlag) throw Exception("stopped")
                withContext(Dispatchers.IO) {
                    loadMeta(d)
                    if (d.cancelFlag || d.pauseFlag) throw Exception("stopped")
                    download(c, d)
                }
                d.progress = 1f
                d.speed = 0L
                d.eta = 0L
                d.retries = 0
                d.finishedAt = System.currentTimeMillis()
                d.state = S_DONE
                save(d)
                Cloud.onDone(c, d)
                Notif.done(c, true)
            } catch (e: Throwable) {
                failure(c, d, e)
            }
            pump(c)
        }
    }

    private fun failure(c: Context, d: DItem, e: Throwable) {
        val raw = e.message ?: e.toString()
        d.speed = 0L
        d.eta = -1L
        if (d.cancelFlag) {
            d.state = S_CANCELLED
            cleanup(c, d)
        } else if (d.pauseFlag) {
            d.state = S_PAUSED
            d.autoPaused = d.autoFlag
            d.autoFlag = false
        } else if (!canDownload(c)) {
            d.state = S_PAUSED
            d.autoPaused = true
        } else if (isPermanent(raw) || d.retries >= RETRY_DELAYS.size ||
            !prefs(c).getBoolean("auto_retry", true)
        ) {
            d.state = S_FAILED
            d.msg = friendlyError(raw)
            Notif.done(c, false)
        } else {
            val wait = RETRY_DELAYS[d.retries]
            d.retries += 1
            d.state = S_WAIT
            d.retryAt = System.currentTimeMillis() + wait
            d.msg = ""
            appScope.launch {
                delay(wait + 300L)
                pump(c)
            }
        }
        save(d)
    }

    // Title and thumbnail. A failure here is not fatal.
    private fun loadMeta(d: DItem) {
        if (d.meta) return
        try {
            val m = readMeta(d.url, d.id)
            if (m.title.isNotBlank()) d.title = m.title
            if (m.thumb != null && d.thumb == null) d.thumb = m.thumb
            d.meta = true
            save(d)
        } catch (e: Throwable) {
            if (d.cancelFlag || d.pauseFlag) throw e
        }
    }

    // yt-dlp options. strict = only H.264 video + AAC audio (plays on every phone and gallery)
    private fun buildRequest(c: Context, d: DItem, work: File, strict: Boolean): YoutubeDLRequest {
        val req = YoutubeDLRequest(d.url)
        req.addOption("--no-playlist")
        req.addOption("-o", work.absolutePath + "/%(title).100s.%(ext)s")
        req.addOption("-N", "8")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")
        req.addOption("--write-thumbnail")
        if (d.height < 0) {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
            req.addOption("--audio-quality", prefs(c).getString("aq", "0") ?: "0")
            return req
        }
        val h = d.height
        val hf = if (h > 0) "[height<=$h]" else ""
        if (strict) {
            req.addOption(
                "-f",
                "bv*[vcodec~='^(avc|h264)']" + hf + "+ba[acodec~='^(mp4a|aac)']/b[ext=mp4]" + hf +
                    "/bv*" + hf + "+ba/b" + hf + "/b"
            )
        } else {
            req.addOption("-f", "bv*" + hf + "+ba/b" + hf + "/b")
            // H.264 + AAC first. Only above 1080p the resolution wins over the codec.
            req.addOption("-S", if (h > 1080) "res,vcodec:h264,acodec:aac" else "vcodec:h264,res,acodec:aac")
        }
        req.addOption("--merge-output-format", "mp4")
        req.addOption("--remux-video", "mp4")
        return req
    }

    private fun runYtDlp(c: Context, d: DItem, work: File, strict: Boolean) {
        val req = buildRequest(c, d, work, strict)
        YoutubeDL.getInstance().execute(req, d.id) { p, eta, line ->
            if (p >= 0f) {
                val pr = (p / 100f).coerceIn(0f, 1f)
                if (pr > d.progress) d.progress = pr
            }
            d.eta = eta
            parseSpeed(line)?.let { d.speed = it }
            parseTotal(line)?.let { if (it > d.sizeBytes) d.sizeBytes = it }
            grabThumb(c, d, work)
            notifyProgress(c)
        }
        grabThumb(c, d, work)
    }

    // Prefer the real mp4/mp3 result, then the biggest file
    private fun pickOutput(work: File): File? =
        work.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in MEDIA_EXT }
            ?.maxWithOrNull(
                compareBy<File>(
                    { if (it.extension.lowercase() == "mp4" || it.extension.lowercase() == "mp3") 1 else 0 },
                    { it.length() }
                )
            )

    // True only when the file really has a picture that this phone can decode
    private fun playable(f: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            hasVideo == "yes" && r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) != null
        } catch (e: Throwable) {
            false
        } finally {
            try {
                r.release()
            } catch (e: Throwable) {
            }
        }
    }

    // Runs on a background thread
    private fun download(c: Context, d: DItem) {
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        try {
            File(base, ".nomedia").createNewFile()
        } catch (e: Throwable) {
        }
        val work = File(base, "work_" + d.id)
        work.mkdirs()
        runYtDlp(c, d, work, false)
        var out = pickOutput(work) ?: throw Exception("No output file")
        if (d.height >= 0 && !playable(out)) {
            // No picture or a codec this phone cannot decode (often AV1/VP9): get a compatible version
            if (d.cancelFlag || d.pauseFlag) throw Exception("stopped")
            work.listFiles()?.filter { it.isFile && it.extension.lowercase() in MEDIA_EXT }?.forEach { it.delete() }
            d.progress = 0f
            d.sizeBytes = 0L
            runYtDlp(c, d, work, true)
            out = pickOutput(work) ?: throw Exception("No output file")
        }
        d.sizeBytes = out.length()
        if (!d.meta || d.title.isBlank() || d.title.startsWith("http")) d.title = out.nameWithoutExtension
        val result: Pair<String, String> =
            exportToDownloads(c, out, prefs(c).getString("folder", "VideoDownloader") ?: "VideoDownloader")
        d.path = result.first
        d.uri = result.second
        work.deleteRecursively()
    }

    private fun grabThumb(c: Context, d: DItem, work: File) {
        try {
            val t = d.thumb
            if (t != null) return
            val img = work.listFiles()?.firstOrNull { it.isFile && it.extension.lowercase() in IMG_EXT } ?: return
            val dir = File(c.getExternalFilesDir(null) ?: c.filesDir, "thumbs")
            dir.mkdirs()
            val dest = File(dir, d.id + "." + img.extension)
            img.copyTo(dest, true)
            d.thumb = dest.absolutePath
        } catch (e: Throwable) {
        }
    }

    // Videos are saved in Movies/<folder> and audio in Music/<folder>, so the phone gallery and
    // music apps can see them.
    private fun exportToDownloads(ctx: Context, f: File, folder: String): Pair<String, String> {
        val ext = f.extension.lowercase()
        val audio = ext in listOf("mp3", "m4a", "aac", "opus", "ogg", "wav")
        val mime = when (ext) {
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            "flv" -> "video/x-flv"
            "avi" -> "video/x-msvideo"
            "ts" -> "video/mp2t"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "opus", "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            else -> "video/mp4"
        }
        val dirName = if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        if (Build.VERSION.SDK_INT >= 29) {
            val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, dirName + "/" + folder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(collection, values)
                ?: throw Exception("Could not save file (permission)")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
            return Pair(dirName + "/" + folder + "/" + f.name, uri.toString())
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(dirName), folder)
            dir.mkdirs()
            val dest = File(dir, f.name)
            f.copyTo(dest, true)
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
            return Pair(dest.path, Uri.fromFile(dest).toString())
        }
    }

    private fun notifyProgress(c: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotif < 1000L) return
        lastNotif = now
        val run = items.filter { it.state == S_RUN }
        if (run.isEmpty()) return
        val pct = (run.map { it.progress }.average() * 100).toInt()
        DlService.update(c, run.size, pct)
    }

    // ---------- user actions ----------

    private fun destroy(d: DItem) {
        try {
            YoutubeDL.getInstance().destroyProcessById(d.id)
        } catch (e: Throwable) {
        }
    }

    fun cancel(ctx: Context, d: DItem) {
        val c = ctx.applicationContext
        if (d.state == S_RUN) {
            d.cancelFlag = true
            destroy(d)
        } else if (d.state == S_WAIT || d.state == S_PAUSED) {
            d.state = S_CANCELLED
            d.autoPaused = false
            cleanup(c, d)
            save(d)
        }
        pump(c)
    }

    fun pause(ctx: Context, d: DItem) {
        val c = ctx.applicationContext
        if (d.state == S_RUN) {
            d.pauseFlag = true
            destroy(d)
        } else if (d.state == S_WAIT) {
            d.state = S_PAUSED
            d.autoPaused = false
            save(d)
        }
        pump(c)
    }

    fun resume(ctx: Context, d: DItem) {
        if (d.state == S_PAUSED) {
            d.state = S_WAIT
            d.autoPaused = false
            d.pauseFlag = false
            d.retryAt = 0L
            save(d)
            pump(ctx)
        }
    }

    fun retry(ctx: Context, d: DItem) {
        if (d.state == S_FAILED || d.state == S_CANCELLED) {
            if (d.state == S_CANCELLED) d.progress = 0f
            d.retries = 0
            d.msg = ""
            d.cancelFlag = false
            d.pauseFlag = false
            d.retryAt = 0L
            d.state = S_WAIT
            save(d)
            pump(ctx)
        }
    }

    fun resumeAuto(ctx: Context) {
        for (d in items.toList()) {
            if (d.state == S_PAUSED && d.autoPaused) {
                d.state = S_WAIT
                d.autoPaused = false
            }
        }
        pump(ctx)
    }

    private fun cleanup(c: Context, d: DItem) {
        try {
            File(c.getExternalFilesDir(null) ?: c.filesDir, "work_" + d.id).deleteRecursively()
        } catch (e: Throwable) {
        }
    }

    fun deleteMedia(c: Context, d: DItem) {
        try {
            if (d.uri.isEmpty()) return
            if (d.uri.startsWith("file:")) {
                Uri.parse(d.uri).path?.let { File(it).delete() }
            } else {
                c.contentResolver.delete(Uri.parse(d.uri), null, null)
            }
        } catch (e: Throwable) {
        }
    }

    fun remove(ctx: Context, d: DItem, deleteFile: Boolean) {
        val c = ctx.applicationContext
        cleanup(c, d)
        if (deleteFile && d.state == S_DONE) deleteMedia(c, d)
        val t = d.thumb
        if (t != null && t.startsWith("/")) {
            try {
                File(t).delete()
            } catch (e: Throwable) {
            }
        }
        if (d.state == S_DONE) Cloud.onRemove(c, d.id)
        items.remove(d)
        try {
            db?.delete(d.id)
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    fun clearCompleted(ctx: Context, deleteFiles: Boolean) {
        for (d in items.filter { it.state == S_DONE }) remove(ctx, d, deleteFiles)
    }

    // "Wi-Fi only downloads": stop running downloads when the phone leaves Wi-Fi
    fun enforcePolicy(ctx: Context) {
        val c = ctx.applicationContext
        if (prefs(c).getBoolean("wifi_only", false) && !isWifi(c)) {
            for (d in items.toList()) {
                if (d.state == S_RUN) {
                    d.pauseFlag = true
                    d.autoFlag = true
                    destroy(d)
                }
            }
        }
    }

    // ---------- storage ----------

    fun storageInfo(ctx: Context): StorageInfo {
        val c = ctx.applicationContext
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        val done = items.filter { it.state == S_DONE }
        var partial = 0L
        base.listFiles()?.filter { it.isDirectory && it.name.startsWith("work_") }?.forEach { partial += dirSize(it) }
        val cache = dirSize(c.cacheDir) + (c.externalCacheDir?.let { dirSize(it) } ?: 0L)
        return StorageInfo(done.size, done.sumOf { it.sizeBytes }, partial, cache, base.usableSpace)
    }

    // Returns the number of bytes freed
    fun clearCache(ctx: Context): Long {
        val c = ctx.applicationContext
        var freed = 0L
        val dirs = listOf(c.cacheDir, c.externalCacheDir)
        for (dir in dirs) {
            if (dir == null) continue
            for (f in dir.listFiles() ?: emptyArray<File>()) {
                freed += dirSize(f)
                try {
                    f.deleteRecursively()
                } catch (e: Throwable) {
                }
            }
        }
        return freed
    }

    // Removes half-finished files that belong to no active download
    fun deletePartial(ctx: Context): Long {
        val c = ctx.applicationContext
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        val keep = items
            .filter { it.state == S_RUN || it.state == S_WAIT || it.state == S_PAUSED }
            .map { "work_" + it.id }
            .toSet()
        var freed = 0L
        for (f in base.listFiles() ?: emptyArray<File>()) {
            if (f.isDirectory && f.name.startsWith("work_") && f.name !in keep) {
                freed += dirSize(f)
                try {
                    f.deleteRecursively()
                } catch (e: Throwable) {
                }
            }
        }
        return freed
    }

    // ---------- network ----------

    private fun registerNetwork(c: Context) {
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Handler(Looper.getMainLooper()).post {
                        enforcePolicy(c)
                        resumeAuto(c)
                    }
                }

                override fun onLost(network: Network) {
                    Handler(Looper.getMainLooper()).post { enforcePolicy(c) }
                }
            })
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    // ---------- history backup (move to another phone) ----------

    fun exportJson(c: Context, uri: Uri): Boolean {
        return try {
            val arr = JSONArray()
            for (d in items.filter { it.state == S_DONE }) {
                val o = JSONObject()
                o.put("url", d.url)
                o.put("title", d.title)
                o.put("height", d.height)
                o.put("finished", d.finishedAt)
                o.put("size", d.sizeBytes)
                arr.put(o)
            }
            c.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun importJson(c: Context, uri: Uri): Int {
        return try {
            val txt = c.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: return -1
            val arr = JSONArray(txt)
            var n = 0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url")
                if (url.isBlank() || items.any { it.url == url && it.state == S_DONE }) continue
                val fin = o.optLong("finished", System.currentTimeMillis())
                val d = DItem(UUID.randomUUID().toString(), url, o.optInt("height", 0), fin)
                d.title = o.optString("title", url)
                d.meta = true
                d.state = S_DONE
                d.progress = 1f
                d.finishedAt = fin
                d.sizeBytes = o.optLong("size")
                items.add(d)
                save(d)
                n++
            }
            n
        } catch (e: Throwable) {
            -1
        }
    }
}

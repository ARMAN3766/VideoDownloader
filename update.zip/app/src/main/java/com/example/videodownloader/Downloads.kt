package com.example.videodownloader

import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

fun isOnline(ctx: Context): Boolean {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Throwable) {
        true
    }
}

// Download manager: queue, parallel limit, retry with delay, cancel, pause, resume
object Dm {
    val items = mutableStateListOf<DItem>()
    private var db: Db? = null
    private var inited = false
    private var lastNotif = 0L
    private val RETRY_DELAYS = longArrayOf(5000L, 20000L, 60000L, 120000L)
    private val MEDIA_EXT = listOf("mp4", "mkv", "webm", "mp3", "m4a", "opus", "ogg", "flv", "mov", "avi", "ts", "3gp", "aac", "wav")
    private val IMG_EXT = listOf("jpg", "jpeg", "png", "webp")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("vd", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val c = ctx.applicationContext
        appCtx = c
        Dl.lang = prefs(c).getString("lang", "bn") ?: "bn"
        val d = Db(c)
        db = d
        try {
            for (x in d.all()) {
                if (x.state == S_RUN) x.state = S_WAIT
                items.add(x)
            }
        } catch (e: Throwable) {
            logCrash(e)
        }
        registerNetwork(c)
    }

    fun save(d: DItem) {
        try {
            val st = if (d.state == S_PAUSED && d.autoPaused) S_WAIT else d.state
            db?.upsert(d, st)
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    fun hasPending(): Boolean =
        items.any { it.state == S_WAIT || it.state == S_RUN || (it.state == S_PAUSED && it.autoPaused) }

    fun findDuplicates(urls: List<String>): List<String> =
        urls.filter { u -> items.any { it.url == u && it.state != S_CANCELLED && it.state != S_FAILED } }

    fun enqueue(ctx: Context, urls: List<String>, height: Int, priv: Boolean, title: String, thumb: String?) {
        urls.forEachIndexed { i, u ->
            val d = DItem(UUID.randomUUID().toString(), u, height, priv, System.currentTimeMillis() + i)
            d.title = if (i == 0 && title.isNotBlank()) title else u
            d.thumb = if (i == 0) thumb else null
            items.add(d)
            save(d)
        }
        pump(ctx)
    }

    // Starts waiting items in order, up to the parallel limit
    fun pump(ctx: Context) {
        val c = ctx.applicationContext
        val now = System.currentTimeMillis()
        val limit = prefs(c).getInt("parallel", 2).coerceIn(1, 4)
        var running = items.count { it.state == S_RUN }
        for (d in items.toList()) {
            if (running >= limit) break
            if (d.state == S_WAIT && d.retryAt <= now) {
                if (!isOnline(c)) {
                    d.state = S_PAUSED
                    d.autoPaused = true
                    save(d)
                    continue
                }
                startItem(c, d)
                running++
            }
        }
        DlService.sync(c, hasPending())
    }

    private fun startItem(c: Context, d: DItem) {
        d.state = S_RUN
        d.msg = ""
        d.cancelFlag = false
        d.pauseFlag = false
        d.speed = 0L
        d.eta = -1L
        save(d)
        d.job = appScope.launch {
            try {
                Engine.await()
                if (d.cancelFlag || d.pauseFlag) throw Exception("stopped")
                withContext(Dispatchers.IO) { download(c, d) }
                d.progress = 1f
                d.speed = 0L
                d.eta = 0L
                d.retries = 0
                d.finishedAt = System.currentTimeMillis()
                d.state = S_DONE
                save(d)
            } catch (e: Throwable) {
                failure(c, d, e)
            }
            pump(c)
        }
    }

    private fun failure(c: Context, d: DItem, e: Throwable) {
        val raw = e.message ?: e.toString()
        d.speed = 0L
        d.eta = -1L
        if (d.cancelFlag) {
            d.state = S_CANCELLED
            cleanup(c, d)
        } else if (d.pauseFlag) {
            d.state = S_PAUSED
            d.autoPaused = false
        } else if (!isOnline(c)) {
            d.state = S_PAUSED
            d.autoPaused = true
        } else if (isPermanent(raw) || d.retries >= RETRY_DELAYS.size) {
            d.state = S_FAILED
            d.msg = friendlyError(raw)
        } else {
            val wait = RETRY_DELAYS[d.retries]
            d.retries += 1
            d.state = S_WAIT
            d.retryAt = System.currentTimeMillis() + wait
            d.msg = ""
            appScope.launch {
                delay(wait + 300L)
                pump(c)
            }
        }
        save(d)
    }

    // Runs on a background thread
    private fun download(c: Context, d: DItem) {
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        try {
            File(base, ".nomedia").createNewFile()
        } catch (e: Throwable) {
        }
        val work = File(base, "work_" + d.id)
        work.mkdirs()
        val req = YoutubeDLRequest(d.url)
        req.addOption("--no-playlist")
        req.addOption("-o", work.absolutePath + "/%(title).100s.%(ext)s")
        req.addOption("-N", "8")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")
        req.addOption("--write-thumbnail")
        if (d.height < 0) {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
        } else {
            val sel = if (d.height == 0) "bv*+ba/b" else "bv*[height<=${d.height}]+ba/b[height<=${d.height}]/b"
            req.addOption("-f", sel)
            req.addOption("--merge-output-format", "mp4")
        }
        YoutubeDL.getInstance().execute(req, d.id) { p, eta, line ->
            if (p >= 0f) {
                val pr = (p / 100f).coerceIn(0f, 1f)
                if (pr > d.progress) d.progress = pr
            }
            d.eta = eta
            parseSpeed(line)?.let { d.speed = it }
            parseTotal(line)?.let { if (it > d.sizeBytes) d.sizeBytes = it }
            grabThumb(c, d, work)
            notifyProgress(c)
        }
        grabThumb(c, d, work)
        val out = work.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in MEDIA_EXT }
            ?.maxByOrNull { it.length() }
            ?: throw Exception("No output file")
        d.sizeBytes = out.length()
        d.title = out.nameWithoutExtension
        val result: Pair<String, String> = if (d.priv) {
            val dir = File(base, "private")
            dir.mkdirs()
            val dest = File(dir, out.name)
            out.copyTo(dest, true)
            Pair("Private/" + dest.name, Uri.fromFile(dest).toString())
        } else {
            exportToDownloads(c, out, prefs(c).getString("folder", "VideoDownloader") ?: "VideoDownloader")
        }
        d.path = result.first
        d.uri = result.second
        work.deleteRecursively()
    }

    private fun grabThumb(c: Context, d: DItem, work: File) {
        try {
            val t = d.thumb
            if (t != null && !t.startsWith("http")) return
            val img = work.listFiles()?.firstOrNull { it.isFile && it.extension.lowercase() in IMG_EXT } ?: return
            val dir = File(c.getExternalFilesDir(null) ?: c.filesDir, "thumbs")
            dir.mkdirs()
            val dest = File(dir, d.id + "." + img.extension)
            img.copyTo(dest, true)
            d.thumb = dest.absolutePath
        } catch (e: Throwable) {
        }
    }

    private fun exportToDownloads(ctx: Context, f: File, folder: String): Pair<String, String> {
        val mime = when (f.extension.lowercase()) {
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "m4a" -> "audio/mp4"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + folder)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Could not save file (permission)")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
            return Pair("Downloads/$folder/${f.name}", uri.toString())
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folder)
            dir.mkdirs()
            val dest = File(dir, f.name)
            f.copyTo(dest, true)
            return Pair(dest.path, Uri.fromFile(dest).toString())
        }
    }

    private fun notifyProgress(c: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotif < 1000L) return
        lastNotif = now
        val run = items.filter { it.state == S_RUN }
        if (run.isEmpty()) return
        val pct = (run.map { it.progress }.average() * 100).toInt()
        DlService.update(c, run.size, pct)
    }

    // ---------- user actions ----------

    private fun destroy(d: DItem) {
        try {
            YoutubeDL.getInstance().destroyProcessById(d.id)
        } catch (e: Throwable) {
        }
    }

    fun cancel(ctx: Context, d: DItem) {
        val c = ctx.applicationContext
        if (d.state == S_RUN) {
            d.cancelFlag = true
            destroy(d)
        } else if (d.state == S_WAIT || d.state == S_PAUSED) {
            d.state = S_CANCELLED
            d.autoPaused = false
            cleanup(c, d)
            save(d)
        }
        pump(c)
    }

    fun pause(ctx: Context, d: DItem) {
        val c = ctx.applicationContext
        if (d.state == S_RUN) {
            d.pauseFlag = true
            destroy(d)
        } else if (d.state == S_WAIT) {
            d.state = S_PAUSED
            d.autoPaused = false
            save(d)
        }
        pump(c)
    }

    fun resume(ctx: Context, d: DItem) {
        if (d.state == S_PAUSED) {
            d.state = S_WAIT
            d.autoPaused = false
            d.pauseFlag = false
            d.retryAt = 0L
            save(d)
            pump(ctx)
        }
    }

    fun retry(ctx: Context, d: DItem) {
        if (d.state == S_FAILED || d.state == S_CANCELLED) {
            if (d.state == S_CANCELLED) d.progress = 0f
            d.retries = 0
            d.msg = ""
            d.cancelFlag = false
            d.pauseFlag = false
            d.retryAt = 0L
            d.state = S_WAIT
            save(d)
            pump(ctx)
        }
    }

    fun resumeAuto(ctx: Context) {
        for (d in items.toList()) {
            if (d.state == S_PAUSED && d.autoPaused) {
                d.state = S_WAIT
                d.autoPaused = false
            }
        }
        pump(ctx)
    }

    private fun cleanup(c: Context, d: DItem) {
        try {
            File(c.getExternalFilesDir(null) ?: c.filesDir, "work_" + d.id).deleteRecursively()
        } catch (e: Throwable) {
        }
    }

    fun deleteMedia(c: Context, d: DItem) {
        try {
            if (d.uri.isEmpty()) return
            if (d.uri.startsWith("file:")) {
                Uri.parse(d.uri).path?.let { File(it).delete() }
            } else {
                c.contentResolver.delete(Uri.parse(d.uri), null, null)
            }
        } catch (e: Throwable) {
        }
    }

    fun remove(ctx: Context, d: DItem, deleteFile: Boolean) {
        val c = ctx.applicationContext
        cleanup(c, d)
        if (deleteFile && d.state == S_DONE) deleteMedia(c, d)
        val t = d.thumb
        if (t != null && t.startsWith("/")) {
            try {
                File(t).delete()
            } catch (e: Throwable) {
            }
        }
        items.remove(d)
        try {
            db?.delete(d.id)
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    fun clearCompleted(ctx: Context, deleteFiles: Boolean) {
        for (d in items.filter { it.state == S_DONE }) remove(ctx, d, deleteFiles)
    }

    // ---------- network ----------

    private fun registerNetwork(c: Context) {
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Handler(Looper.getMainLooper()).post { resumeAuto(c) }
                }
            })
        } catch (e: Throwable) {
            logCrash(e)
        }
    }

    // ---------- history backup (move to another phone) ----------

    fun exportJson(c: Context, uri: Uri): Boolean {
        return try {
            val arr = JSONArray()
            for (d in items.filter { it.state == S_DONE }) {
                val o = JSONObject()
                o.put("url", d.url)
                o.put("title", d.title)
                o.put("height", d.height)
                o.put("priv", d.priv)
                o.put("finished", d.finishedAt)
                o.put("size", d.sizeBytes)
                arr.put(o)
            }
            c.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun importJson(c: Context, uri: Uri): Int {
        return try {
            val txt = c.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: return -1
            val arr = JSONArray(txt)
            var n = 0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url")
                if (url.isBlank() || items.any { it.url == url && it.state == S_DONE }) continue
                val fin = o.optLong("finished", System.currentTimeMillis())
                val d = DItem(UUID.randomUUID().toString(), url, o.optInt("height", 0), o.optBoolean("priv"), fin)
                d.title = o.optString("title", url)
                d.state = S_DONE
                d.progress = 1f
                d.finishedAt = fin
                d.sizeBytes = o.optLong("size")
                items.add(d)
                save(d)
                n++
            }
            n
        } catch (e: Throwable) {
            -1
        }
    }
}

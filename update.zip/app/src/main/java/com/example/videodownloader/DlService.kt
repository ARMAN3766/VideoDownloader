package com.example.videodownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat

// Keeps downloads alive in the background with a neutral notification
class DlService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel(this)
        try {
            startForeground(NOTIF_ID, build(this, 0, -1))
        } catch (e: Throwable) {
            logCrash(e)
        }
        try {
            Dm.init(this)
            Dm.pump(this)
        } catch (e: Throwable) {
            logCrash(e)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        const val CH = "dl_channel"
        const val NOTIF_ID = 77

        @Volatile
        var running = false

        fun createChannel(c: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = c.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }

        fun build(c: Context, count: Int, pct: Int): Notification {
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else Notification.Builder(c)
            val open = Intent(c, MainActivity::class.java)
            open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.setSmallIcon(android.R.drawable.stat_sys_download)
            b.setContentTitle(t("notif_text"))
            if (count > 0) b.setContentText(count.toString())
            if (pct >= 0) b.setProgress(100, pct, false)
            b.setOngoing(true)
            b.setOnlyAlertOnce(true)
            b.setContentIntent(pi)
            return b.build()
        }

        fun sync(c: Context, active: Boolean) {
            try {
                val i = Intent(c, DlService::class.java)
                if (active && !running) ContextCompat.startForegroundService(c, i)
                else if (!active && running) c.stopService(i)
            } catch (e: Throwable) {
                logCrash(e)
            }
        }

        fun update(c: Context, count: Int, pct: Int) {
            if (!running) return
            try {
                c.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(c, count, pct))
            } catch (e: Throwable) {
            }
        }
    }
}

// Resumes pending downloads after the phone restarts (where Android allows it)
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            if (intent != null && intent.action == Intent.ACTION_BOOT_COMPLETED) {
                Dm.init(context)
                if (Dm.hasPending()) DlService.sync(context, true)
            }
        } catch (e: Throwable) {
            logCrash(e)
        }
    }
}

# Video Downloader - update status

Done in update.zip (version 2.0):
- PIN / lock screen removed (one-time 18+ confirmation only)
- Unlimited download queue (SQLite, survives app restart), input box clears after Download
- Parallel limit 1-4 (default 2), FIFO order, per-item Cancel (with confirm), Pause/Resume
- Auto retry with increasing delay (5s, 20s, 60s, 120s), auto pause without network, auto resume
- History page: Downloads (active) + Completed, ring progress with logo + real percentage
- Foreground service + notification, boot receiver (resume after restart where Android allows)
- Share-to-app, duplicate warning, history export/import (JSON), Bangla/English
- Release signing with permanent key (secret KS_PASS), versionCode = GitHub run number

Not built (needs a cloud backend + credentials): Gmail account login / cloud history sync.

Not verified here (no compiler/device in the build sandbox): compile result and on-device behaviour.
Next step: run the GitHub build, install, test the Part 11 checklist, send build log if red.

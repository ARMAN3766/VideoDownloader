# Video Downloader - status (update 2.1)

## In update.zip (stage 1, works without any backend)
- 18+ ONLY warning on first launch (consent saved locally), Exit closes the app
- Premium UI: dark/light/system theme, gradient header and button, ring progress, Bangla/English
- Download page: link detection (title, thumbnail, real qualities up to 4K, audio MP3), share-menu intake
- Download engine: queue, parallel 1-4, resume, retry with delay, pause/resume/cancel, foreground service
- History: Downloads / Completed / 18+ Videos (age confirm before opening, manual move, no PIN, no private folder)
- 18+ detection only from confident signals (site age_limit >= 18 or dedicated adult website). Title alone is never used.
- Settings: language, theme, concurrent downloads, folder name, notifications, history backup (export/import), engine update, error log, about
- Release signing with permanent key (secret KS_PASS)

## In account.zip (stage 2, needs Firebase setup)
- Email/password account (Gmail or any email), email verification, forgot/change password, show/hide password
- Cloud history sync (Firestore REST), manage account history, remove one / clear all
- Turns on only when GitHub secrets FB_API_KEY and FB_PROJECT exist

## Not built
- Phone number / OTP login (needs Firebase SDK + SMS billing + app fingerprints)
- Google one-tap sign-in button
- Real age verification (only self-declaration is possible in an app)

## Not verified here
- No compiler or phone in the build sandbox: compile result and on-device behaviour are untested.
- Next: run the GitHub build, install, test, send the Build log if red.

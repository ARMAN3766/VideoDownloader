# Video Downloader - status (update 2.2)

## In update.zip (stage 1, works without any backend)
- FIX: downloads now give real MP4 with picture + sound. H.264 video + AAC audio is preferred, the file is
  checked after download (picture must decode on this phone), and a compatible H.264 version is downloaded
  automatically if it cannot be played. Above 1080p the chosen resolution wins over the codec.
- Videos are saved in Movies/<folder> and audio in Music/<folder> so the gallery and music apps show them.
- All visible 18+/adult labels, tab, switch and messages were removed. One neutral age confirmation (18 years or older)
  stays on first launch as a legal/age control. History has two tabs: Downloads and Completed.
- Premium UI (dark/light/system theme), Bangla/English, link detection with real qualities up to 4K, share intake
- Queue, parallel 1-4, resume, retry with delay, pause/resume/cancel, foreground service, completion notification
- Settings: language, theme, concurrent downloads, folder name, notifications, history backup, engine update, error log, about
- Release signing with permanent key (secret KS_PASS)

## In account.zip (stage 2, needs Firebase setup)
- Email/password account (Gmail or any email), email verification, forgot/change password, show/hide password
- Cloud history sync (Firestore REST), manage account history, remove one / clear all
- Turns on only when GitHub secrets FB_API_KEY and FB_PROJECT exist

## Not built
- Phone number / OTP login (needs Firebase SDK + SMS billing + app fingerprints)
- Google one-tap sign-in button
- Real age verification (only self-declaration is possible in an app)

## Not verified here
- No compiler or phone in the build sandbox: compile result and on-device behaviour are untested.
- Next: run the GitHub build, install, test, send the Build log if red.

## OPEN (needs the user)
- The user has an OLD app (accounts, login, update system, store users). This repo is a separate downloader app
  (package com.example.videodownloader). To merge the downloader into the old app we need the old app project
  (GitHub repo ZIP) and its signing key info. Nothing is assumed about it.
